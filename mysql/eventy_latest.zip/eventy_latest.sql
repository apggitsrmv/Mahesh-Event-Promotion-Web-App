-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for eventy
CREATE DATABASE IF NOT EXISTS `eventy` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `eventy`;

-- Dumping structure for table eventy.artists
CREATE TABLE IF NOT EXISTS `artists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `artist_image` varchar(100) NOT NULL,
  `artist_name` varchar(100) NOT NULL,
  `biography` varchar(225) NOT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table eventy.artists: ~11 rows (approximately)
DELETE FROM `artists`;
INSERT INTO `artists` (`id`, `artist_image`, `artist_name`, `biography`, `facebook`, `instagram`, `twitter`) VALUES
	(1, 'jerryjay.jpeg', 'Jerry Jay', 'Southeast Asian Electronic Musician From Myanmar(Burma)', 'https://www.facebook.com/thejerryjay?mibextid=b06tZ0', 'https://instagram.com/thejerryjay?igshid=MzRlODBiNWFlZA==', 'https://twitter.com/thejerryjay'),
	(2, 'fakecake.jpeg', 'Fakecake', 'Electronic Musician From Myanmar(Burma)', 'https://www.facebook.com/fakecakeofficial?mibextid=b06tZ0', 'https://instagram.com/fakecakeofficial?igshid=MzRlODBiNWFlZA==', 'https://twitter.com/fakecakemusic_?lang=en'),
	(3, 'ouj.jpeg', 'OU J', 'DJ & Music Producer From Myanmar(Burma)', '-https://www.facebook.com/oujofficial?mibextid=b06tZ0', 'https://instagram.com/oujartist?igshid=MzRlODBiNWFlZA==', ''),
	(4, 'y3llo.jpeg', 'Y3LLO', 'DJ & Music Producer ', 'https://www.facebook.com/y3llomusicofficial?mibextid=b06tZ0', 'https://instagram.com/y3llomusicofficial?igshid=MzRlODBiNWFlZA==', 'https://twitter.com/y3llo_official?lang=zh-Hant'),
	(5, 'terrorbass.jpeg', 'Terror Bass', 'Electronic Music Producers,Sailus & LZ From Myanmar(Burma)\r\n', 'https://www.facebook.com/ItsTerrorBass?mibextid=b06tZ0', 'https://instagram.com/terrorbassmusic?igshid=MzRlODBiNWFlZA==', 'https://twitter.com/terror_bass'),
	(6, 'eternalgosh.jpeg', 'Eternal Gosh', 'Musician/Band', 'https://www.facebook.com/eternalgoshfamily?mibextid=b06tZ0', 'https://instagram.com/eternal_gosh?igshid=MzRlODBiNWFlZA==', ''),
	(7, 'zig.jpeg', 'ZIG', 'Musician/Band', 'https://www.facebook.com/zigmusicofficial?mibextid=b06tZ0', 'https://instagram.com/zigdgafxxk?igshid=MzRlODBiNWFlZA==', ''),
	(8, 'yunghugo.jpeg', 'Yung Hugo', 'Rapper', 'https://www.facebook.com/yungislivingthing?mibextid=b06tZ0', 'https://instagram.com/yungislivingthing?igshid=MzRlODBiNWFlZA==', ''),
	(9, 'food-court.jpg', 'M Food Court', 'Dine-in resturant', 'https://www.facebook.com/MFoodCourt.ygn/', '', ''),
	(10, 'xpay.jpg', 'fadf', 'adfdf', '', '', ''),
	(11, 'Anirudh-Ravichander-1024x683.jpg', 'Aniruth RaviChandran', 'Aniruth RaviChandran, commonly known as Anirudh, is an Indian composer, singer, and actor born on October 16, 1990. ', 'https://www.facebook.com/AnirudhOfficial/', 'https://www.instagram.com/anirudhofficial', 'https://twitter.com/anirudhofficial');

-- Dumping structure for table eventy.events
CREATE TABLE IF NOT EXISTS `events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `category` varchar(60) NOT NULL,
  `artist_id` varchar(20) NOT NULL,
  `attendance` varchar(20) NOT NULL,
  `fees` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table eventy.events: ~2 rows (approximately)
DELETE FROM `events`;
INSERT INTO `events` (`id`, `image`, `title`, `category`, `artist_id`, `attendance`, `fees`, `date`, `starttime`, `endtime`) VALUES
	(10, 'leotamilposter1-1695213997.jpg', 'Leo Audio Launch', 'Audio Launch', '11', '500', 'Free', '2023-09-30', '10:42:00', '18:42:00'),
	(11, 'leotamilposter1-1695213997.jpg', 'Salaar Audio launch', 'Audio Launch', '11', '500', 'Free', '2023-10-02', '14:08:00', '20:08:00');

-- Dumping structure for table eventy.register
CREATE TABLE IF NOT EXISTS `register` (
  `id` int NOT NULL AUTO_INCREMENT,
  `visiter_image` varchar(100) NOT NULL,
  `visiter_name` varchar(100) NOT NULL,
  `visiter_age` varchar(100) NOT NULL,
  `visiter_mno` varchar(100) NOT NULL,
  `visiter_email` varchar(225) NOT NULL,
  `visiter_gender` varchar(100) DEFAULT NULL,
  `visiter_event` varchar(100) DEFAULT NULL,
  `visiter_aadhar` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table eventy.register: ~11 rows (approximately)
DELETE FROM `register`;
INSERT INTO `register` (`id`, `visiter_image`, `visiter_name`, `visiter_age`, `visiter_mno`, `visiter_email`, `visiter_gender`, `visiter_event`, `visiter_aadhar`) VALUES
	(9, 'GitHub-logo.png', 'DEEPAK', '23', '0987654321', 'mr5lxd5@ezztt.com', 'Male', '1', '4444 5555 6666'),
	(10, 'leotamilposter1-1695213997.jpg', 'DEEPAK', '23', '0987654321', 'shalomdaniel104@gmail.com', 'Male', '9', '4444 5555 6666'),
	(11, 'leotamilposter1-1695213997.jpg', 'DEEPAK', '23', '0987654321', 'shalomdaniel104@gmail.com', 'Male', '', '4444 5555 6666'),
	(12, 'leotamilposter1-1695213997.jpg', 'DEEPAK', '23', '0987654321', 'abdulhakkeem203@gmail.com', 'Male', '9', '4444 5555 6666'),
	(13, 'leotamilposter1-1695213997.jpg', 'Mahesh', '23', '0987654321', 'abdulhakkeem203@gmail.com', 'Male', '4', '4444 5555 6666'),
	(14, 'leotamilposter1-1695213997.jpg', 'DEEPAK', '23', '0987654321', 'mr5lxd5@ezztt.com', 'Male', '9', '4444 5555 6666'),
	(15, 'leotamilposter1-1695213997.jpg', '70', '23', '0987654321', 'itgowtham2004@gmail.com', 'Male', '9', '4444 5555 6666'),
	(16, 'leotamilposter1-1695213997.jpg', 'DEEPAK', '23', '0987654321', 'abdulhakkeem203@gmail.com', 'Male', '9', '4444 5555 6666'),
	(17, 'leotamilposter1-1695213997.jpg', 'Mahesh', '23', '0987654321', 'itgowtham2004@gmail.com', 'Male', '9', '4444 5555 6666'),
	(18, 'leotamilposter1-1695213997.jpg', 'daniel', '23', '0987654321', 'jikive6262@kkoup.com', 'Male', '9', '4444 5555 6666'),
	(19, 'Anirudh-Ravichander-1024x683.jpg', 'DEEPAK', '23', '', '', 'Male', '', '4444 5555 6666'),
	(20, 'Anirudh-Ravichander-1024x683.jpg', 'Mahesh', '23', '0987654321', 'itgowtham2004@gmail.com', 'Male', '', '4444 5555 6666');

-- Dumping structure for table eventy.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table eventy.users: ~4 rows (approximately)
DELETE FROM `users`;
INSERT INTO `users` (`id`, `username`, `password`) VALUES
	(1, 'test', 'test'),
	(2, 'admin', 'admin'),
	(4, 'staff', 'staff');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
